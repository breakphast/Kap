//
//  OKView.swift
//  Kap
//
//  Created by Desmond Fitch on 7/12/23.
//

import SwiftUI

struct OKView: View {
    let game = AppData().seasons.first?.weeks.first?.bets.first?.first?.game
    
    var body: some View {
        Text(game?.homeTeam ?? "")
    }
}

#Preview {
    OKView()
}


class AppData {
    var users: [User] = []
    var leagues: [League] = []
    var seasons: [Season] = []
    var weeks: [Week] = []
    var players: [Player] = []
    var games: [Game] = []
    var bets: [Bet] = []
    var parlays: [Parlay] = []
    
    init() {
        // Populate the initial data
        // Note that we need to generate all the objects in a specific order due to the dependencies between them
        let gamess = [
            Game(homeTeam: "Philadelphia Eagles", awayTeam: "Tampa Bay Buccaneers", date: Date(), betOptions: []),
            Game(homeTeam: "Jacksonville Jaguars", awayTeam: "Miami Dolphins", date: Date(), betOptions: []),
            Game(homeTeam: "Baltimore Ravens", awayTeam: "Los Angeles Chargers", date: Date(), betOptions: []),
            Game(homeTeam: "Arizona Cardinals", awayTeam: "Cleveland Browns", date: Date(), betOptions: []),
            Game(homeTeam: "Seattle Seahawks", awayTeam: "Pittsburgh Steelers", date: Date(), betOptions: []),
            Game(homeTeam: "Buffalo Bills", awayTeam: "Tennessee Titans", date: Date(), betOptions: [])
        ]
        
        for game in gamess {
            games.append(game)
        }
        
        let betOptions = [
            [
                BetOption(gameID: games[0].id, betType: .spread, odds: +150),
                BetOption(gameID: games[0].id, betType: .moneyline, odds: -130),
                BetOption(gameID: games[0].id, betType: .totals, odds: +140)
            ],
            [
                BetOption(gameID: games[1].id, betType: .spread, odds: -192),
                BetOption(gameID: games[1].id, betType: .moneyline, odds: -110),
                BetOption(gameID: games[1].id, betType: .totals, odds: +119)
            ],
            [
                BetOption(gameID: games[2].id, betType: .spread, odds: +193),
                BetOption(gameID: games[2].id, betType: .moneyline, odds: -123),
                BetOption(gameID: games[2].id, betType: .totals, odds: +111)
            ],
            [
                BetOption(gameID: games[3].id, betType: .spread, odds: -192),
                BetOption(gameID: games[3].id, betType: .moneyline, odds: -193),
                BetOption(gameID: games[3].id, betType: .totals, odds: +183)
            ],
            [
                BetOption(gameID: games[4].id, betType: .spread, odds: +162),
                BetOption(gameID: games[4].id, betType: .moneyline, odds: -173),
                BetOption(gameID: games[4].id, betType: .totals, odds: +173)
            ],
            [
                BetOption(gameID: games[5].id, betType: .spread, odds: -163),
                BetOption(gameID: games[5].id, betType: .moneyline, odds: +164),
                BetOption(gameID: games[5].id, betType: .totals, odds: -238)
            ]
        ]
        
        games[0].betOptions = betOptions[0]
        games[1].betOptions = betOptions[1]
        games[2].betOptions = betOptions[2]
        games[3].betOptions = betOptions[3]
        games[4].betOptions = betOptions[4]
        games[5].betOptions = betOptions[5]
        
        let user1 = User(userID: UUID(), email: "desmond@gmail.com", password: "123456", name: "ThePhast", leagues: [])
        users.append(user1)
        
        let league1 = League(leagueID: UUID(), name: "League1", dateCreated: Date(), currentSeason: 2023, seasons: [], players: [])
        leagues.append(league1)
        user1.leagues.append(league1)
        
        let player1 = Player(id: UUID(), user: user1, league: league1, name: "Player1", bets: [], parlays: [], points: [:])
        players.append(player1)
        league1.players.append(player1)
        
        let season1 = Season(id: UUID(), league: league1, year: 2023, weeks: [])
        seasons.append(season1)
        league1.seasons.append(season1)
        
        var bet1 = Bet(id: UUID(), userID: user1.userID, betOptionID: games[2].betOptions[0].id, game: games[0], type: games[0].betOptions[2].betType, result: .win, odds: +130, points: 10)
        bet1.points = calculatePoints(bet: bet1)
        bets.append(bet1)
        player1.bets.append([bet1])
        
        let parlay1 = Parlay(id: UUID(), userID: user1.userID, bets: [bet1, bet1], result: .loss)
        parlays.append(parlay1)
        player1.parlays.append(parlay1)
        
        let points = bet1.points + parlay1.totalPoints
        print(points)
        
        let week1 = Week(id: UUID(), season: season1, bets: [[bet1]], parlays: [[parlay1]], isComplete: false)
        weeks.append(week1)
        season1.weeks.append(week1)
        
        func calculatePoints(bet: Bet, basePoints: Int = 10) -> Int {
            var points: Double
            
            if bet.odds > 0 { // Positive American odds
                points = Double(bet.odds) / 100.0 * Double(basePoints)
            } else { // Negative American odds
                points = 100.0 / Double(abs(bet.odds)) * Double(basePoints)
            }
            
            return bet.result == .win ? Int(round(points)) : Int(round(-points)) / 2
        }
    }
}
