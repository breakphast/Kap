//
//  UserViewModel.swift
//  Kap
//
//  Created by Desmond Fitch on 7/12/23.
//

import Foundation

class UserViewModel {
    var user: User
    init(user: User) {
        self.user = user
    }
}

class LeagueViewModel {
    var league: League
    init(league: League) {
        self.league = league
    }
}

class SeasonViewModel {
    var season: Season
    init(season: Season) {
        self.season = season
    }
}

class WeekViewModel {
    var week: Week
    init(week: Week) {
        self.week = week
    }
}

class PlayerViewModel {
    var player: Player
    init(player: Player) {
        self.player = player
    }
}

class GameViewModel {
    var game: Game
    init(game: Game) {
        self.game = game
    }
}
