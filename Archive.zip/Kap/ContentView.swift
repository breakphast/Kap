//
//  ContentView.swift
//  Kap
//
//  Created by Desmond Fitch on 7/12/23.
//

import Foundation

class User {
    var userID: UUID
    var email: String
    var password: String
    var name: String
    var leagues: [League]
    
    init(userID: UUID, email: String, password: String, name: String, leagues: [League]) {
        self.userID = userID
        self.email = email
        self.password = password
        self.name = name
        self.leagues = leagues
    }
}
class League {
    let leagueID: UUID
    var name: String
    var dateCreated: Date
    var currentSeason: Int
    var seasons: [Season]
    var players: [Player]
    
    init(leagueID: UUID, name: String, dateCreated: Date, currentSeason: Int, seasons: [Season], players: [Player]) {
        self.leagueID = leagueID
        self.name = name
        self.dateCreated = dateCreated
        self.currentSeason = currentSeason
        self.seasons = seasons
        self.players = players
    }
}
class Season {
    let id: UUID
    let league: League
    let year: Int
    var weeks: [Week]
    
    init(id: UUID, league: League, year: Int, weeks: [Week]) {
        self.id = id
        self.league = league
        self.year = year
        self.weeks = weeks
    }
}
class Week {
    let id: UUID
    let season: Season
    var bets: [[Bet]]
    var parlays: [[Parlay]]
    var isComplete: Bool
    
    init(id: UUID, season: Season, bets: [[Bet]], parlays: [[Parlay]], isComplete: Bool) {
        self.id = id
        self.season = season
        self.bets = bets
        self.parlays = parlays
        self.isComplete = isComplete
    }
}
class Player {
    let id: UUID
    let user: User
    let league: League
    var name: String
    var bets: [[Bet]]
    var parlays: [Parlay]
    var points: [Int: Int]
    
    init(id: UUID, user: User, league: League, name: String, bets: [[Bet]], parlays: [Parlay], points: [Int: Int]) {
        self.id = id
        self.user = user
        self.league = league
        self.name = name
        self.bets = bets
        self.parlays = parlays
        self.points = points
    }
}
class Game {
    let id: UUID
    let homeTeam: String
    let awayTeam: String
    var date: Date
    var betOptions: [BetOption]
    
    init(homeTeam: String, awayTeam: String, date: Date, betOptions: [BetOption]) {
        self.id = UUID()
        self.homeTeam = homeTeam
        self.awayTeam = awayTeam
        self.date = date
        self.betOptions = betOptions
    }
}
enum BetType {
    case spread
    case moneyline
    case totals
}
enum BetResult {
    case win
    case loss
    case pending
}

struct BetOption {
    let id: UUID
    let gameID: UUID
    let betType: BetType
    var odds: Int
    
    init(gameID: UUID, betType: BetType, odds: Int) {
        self.id = UUID()
        self.gameID = gameID
        self.betType = betType
        self.odds = odds
    }
}

struct Bet {
    let id: UUID
    let userID: UUID
    let betOptionID: UUID
    let game: Game
    let type: BetType
    let result: BetResult?
    let odds: Int
    var points: Int
    let stake = 100.0
    
    init(id: UUID, userID: UUID, betOptionID: UUID, game: Game, type: BetType, result: BetResult?, odds: Int, points: Int) {
        self.id = id
        self.userID = userID
        self.betOptionID = betOptionID
        self.game = game
        self.type = type
        self.result = result
        self.odds = odds
        self.points = points
    }
}

class Parlay {
    let id: UUID
    let userID: UUID
    let bets: [Bet]
    var totalOdds: Int
    var result: BetResult
    var totalPoints: Int
    
    init(id: UUID, userID: UUID, bets: [Bet], result: BetResult) {
        self.id = id
        self.userID = userID
        self.bets = bets
        self.totalOdds = calculateParlayOdds(bets: bets)
        self.result = result
        self.totalPoints = calculateParlayPoints(odds: totalOdds, result: result)
    }
}

func calculateParlayOdds(bets: [Bet]) -> Int {
    var totalPayout = 1.0
    for bet in bets {
        let payout: Double
        if bet.odds > 0 {
            payout = 1 + Double(bet.odds) / 100
        } else {
            payout = 1 - 100 / Double(bet.odds)
        }
        totalPayout *= payout
    }

    let parlayOdds: Int
    if totalPayout >= 2 {
        parlayOdds = Int((totalPayout - 1) * 100) // For positive odds
    } else {
        parlayOdds = Int(-100 / (totalPayout - 1)) // For negative odds
    }
    return parlayOdds
}

func calculateParlayPoints(odds: Int, basePoints: Double = 10.0, result: BetResult) -> Int {
    var points: Int = 0
    if result == .win {
        if odds > 0 { // Positive American odds
            points = Int((Double(odds) / 100.0) * basePoints)
        } else { // Negative American odds
            points = Int((100.0 / Double(abs(odds))) * basePoints)
        }
    }
    // If the bet result is not a win, points will remain 0
    return points
}
